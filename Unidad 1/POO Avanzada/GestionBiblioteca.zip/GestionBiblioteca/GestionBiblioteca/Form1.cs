﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionBiblioteca
{
    public partial class Form1 : Form
    {
        private Biblioteca miBiblioteca;
        public Form1()
        {
            InitializeComponent();
            miBiblioteca = new Biblioteca();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAgregarLibro_Click(object sender, EventArgs e)
        {
            try
            {
                string titulo = txtTituloLibro.Text;
                string autor = txtAutorLibro.Text;
                string isbn = txtISBN.Text;

                Libro libro = new Libro(titulo, autor, isbn);
                miBiblioteca.AgregarLibro(libro);

                MessageBox.Show("Registrando libro...");
                txtTituloLibro.Clear();
                txtAutorLibro.Clear();
                txtISBN.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnRegistrarUsuario_Click(object sender, EventArgs e)
        {
            try
            {
                string nombre = txtNombreUsuario.Text;

                int id = int.Parse(txtIdUsuario.Text);

                Usuario usuario = new Usuario(nombre, id);
                miBiblioteca.RegistrarUsuario(usuario);
                MessageBox.Show("Ragistrando Usuario...");

                txtNombreUsuario.Clear();
                txtIdUsuario.Clear();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnPrestarLibro_Click(object sender, EventArgs e)
        {
            string isbn = txtISBN.Text;
            int id = int.Parse(txtIdUsuario.Text);
            miBiblioteca.PrestarLibro(isbn, id);
        }

        private void btnDevolverLibro_Click(object sender, EventArgs e)
        {
            string isbn = txtISBN.Text;
            int id = int.Parse(txtIdUsuario.Text);
            miBiblioteca.DevolverLibro(isbn);
        }

        private void btnMostrarLibros_Click(object sender, EventArgs e)
        {
            dgvLibros.Rows.Clear();
            dgvLibros.Columns.Clear();

            dgvLibros.Columns.Add("Titulo", "Título");
            dgvLibros.Columns.Add("Autor", "Autor");
            dgvLibros.Columns.Add("ISBN", "ISBN");
            dgvLibros.Columns.Add("Prestado", "Prestado");

            var libros = miBiblioteca.ObtenerLibros();
            foreach (var libro in libros)
            {
                dgvLibros.Rows.Add(libro.Titulo, libro.Autor, libro.ISBN, libro.Prestado ? "Sí" : "No");
            }

            MessageBox.Show("Mostrando la lista de los libros registrados.");
        }

        private void btnMostrarUsuarios_Click(object sender, EventArgs e)
        {
            dgvUsuarios.Rows.Clear();
            dgvUsuarios.Columns.Clear();

            dgvUsuarios.Columns.Add("Nombre", "Nombre");
            dgvUsuarios.Columns.Add("ID", "ID");

            var usuarios = miBiblioteca.ObtenerUsuarios();
            foreach (var usuario in usuarios)
            {
                dgvUsuarios.Rows.Add(usuario.Nombre, usuario.ID);
            }

            MessageBox.Show("Mostrando la lista de los usuarios registrados.");
        }
    }
}
