﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionBiblioteca
{
    class Usuario : Informacion
    {
        private string _strNombre;
        public string Nombre
        {
            get { return _strNombre; }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                    _strNombre = value;
                else
                    throw new ArgumentException("El nombre no puede estar vacío.");
            }
        }

        private int _intID;
        public int ID
        {
            get { return _intID; }
            set
            {
                if (value > 0)
                    _intID = value;
                else
                    throw new ArgumentException("El ID debe ser positivo.");
            }
        }

        public Usuario(string nombre, int id)
        {
            this.Nombre = nombre;
            this.ID = id;
        }
    }
}
