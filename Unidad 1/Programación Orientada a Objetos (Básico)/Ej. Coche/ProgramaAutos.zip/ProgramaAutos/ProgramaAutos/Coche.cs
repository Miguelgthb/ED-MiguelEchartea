﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramaAutos
{
    class Coche
    {
        private string _strMarca;
        public string Marca
        {
            get { return _strMarca; }
            set { _strMarca = value; }
        }

        private string _strModelo;
        public string Modelo
        {
            get { return _strModelo; }
            set { _strModelo = value; }
        }
        private double _strVelocidad;
        public double Velocidad
        {
            get { return _strVelocidad; }
            set
            {
                if (value < 0)
                {
                    throw new Exception("No permite numeros negativos");
                }
                else
                {
                    _strVelocidad = value;
                }
            }
        }

        public Coche(string marca, string modelo)
        {
            this.Marca = marca;
            this.Modelo = modelo;
            this.Velocidad = 0;
        }
        
        public void Acelerar(double incremento)
        {
            Velocidad += incremento;
        }

        public void Frenar(double decremento)
        {
            // Velocidad = Velocidad - decremento; **Es lo mismo a** Velocidad -= decremento;
            Velocidad -= decremento;
            if (Velocidad < 0)
            {
                Velocidad = 0;
            }
        }
    }
}
