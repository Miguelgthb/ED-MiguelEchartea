﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgramaAutos
{
    public partial class Form1 : Form
    {
        Coche miCoche = new Coche("", "");
        public Form1()
        {
            InitializeComponent();
            btnCapturar.Enabled = true;
            btnAcelerar.Enabled = false;
            btnFrenar.Enabled = false;
        }

        private void btnCapturar_Click(object sender, EventArgs e)
        {
            try
            {
                Console.WriteLine("Ingrese su marca del Coche: ");
                miCoche.Marca = txtMarca.Text;
                Console.WriteLine("Ingrese su modelo del Coche: ");
                miCoche.Modelo = txtModelo.Text;
                Console.WriteLine("Ingrese su velocidad (Km/h): ");
                miCoche.Velocidad = double.Parse(txtVelocidad.Text);

                MessageBox.Show($"Se capturaron los datos: \n{miCoche.Marca}\n{miCoche.Modelo}\n{miCoche.Velocidad}");
                btnCapturar.Enabled = false;
                btnAcelerar.Enabled = true;
                btnFrenar.Enabled = true;
            }
            catch (FormatException)
            {
                MessageBox.Show("Datos Incorrectos.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnFrenar_Click(object sender, EventArgs e)
        {
            if (miCoche != null)
            {
                miCoche.Frenar(20); // Brake by 10 km/h
                MessageBox.Show($"Frenando en 20 km/h. \nVelocidad Actual: {miCoche.Velocidad} Km/h", "Frenar");
            }
            else
            {
                MessageBox.Show("Datos de velocidad no capturada.", "Error");
            }
        }

        private void btnAcelerar_Click(object sender, EventArgs e)
        {
            if (miCoche != null)
            {
                miCoche.Acelerar(10);
                MessageBox.Show($"Acelerando en 10 km/h. \nVelocidad Actual: {miCoche.Velocidad} Km/h", "Acelerar");
            }
            else
            {
                MessageBox.Show("Datos de velocidad no capturada.", "Error");
            }
        }
    }
}
